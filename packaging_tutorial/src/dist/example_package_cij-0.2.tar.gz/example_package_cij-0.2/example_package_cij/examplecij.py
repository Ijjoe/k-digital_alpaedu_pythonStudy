def add_one1(number):
    return number + 1
    

def min_one(number):
    return number - 1